import requests
from scapy.all import *
import os
import json
import pyfiglet
from termcolor import colored


'''database = requests.get("https://www.dan.me.uk/torlist/").text
with open("text.txt", "w") as f:
	f.write(database)'''

LocalIPs=[]
TorIPs=[]
titles=["Local__IPs", "TOR_IPs"]

def Update_Database():
	database = requests.get("https://www.dan.me.uk/torlist/").text
	with open("text.txt", "w") as f:
		f.write(database)

f=open("text.txt","r")
Li= f.read()
List= Li.splitlines()


def Istor(ip,List):

	if ip in List:
		return True
	else:
		return False

def checkip():
	print(colored("Enter IP to check: ", 'green'))
	node=input("")
	if Istor(node,List):
		print(f"IP: {node} is from Proxy Server")
	else:
		print(f"IP: {node} is NOT a from Proxy Server ")
	Ip_geo(node)

def Ip_geo(ip):
	print("\n\n")
	req_two = requests.get("https://ipinfo.io/"+ip+"/json")
	resp_ = json.loads(req_two.text)

	print("Location: "+resp_["loc"])
	print("Region: "+resp_["region"])
	print("City: "+resp_["city"])
	print("Country: "+resp_["country"])




def packet_capture():
		print(colored("Enter interface to listen on : ",'green'))
		interface = input("")
		print(colored("Enter destination file name: "))
		outputFile = input("")
		print("Hit Ctrl + c to stop capturing the packets .../n")
		os.system(f"tcpdump -i {interface} -w {outputFile}")


def ip_extractor(pcapf):

		packets = rdpcap(pcapf)
		srIP=[]

		for pkt in packets:
				if IP in pkt:
						try:
								srIP.append(pkt[IP].src)
						except:
								pass
		uniq= list(set(srIP))
		return uniq

def analyze():
	print(colored("Enter path to the pcap file to analyze: ",'red'))
	pktFile = input("")
	#List=['171.25.193.9','143.244.134.227','45.86.70.11'] //sample ip
	ips =  set((p[IP].src, p[IP].dst) for p in PcapReader(pktFile) if IP in p)
	srcDstList = list(ips)

	flag=False
	#print(srcDstList)
	for i in srcDstList:
	# print(i)
		for j in List:
			if j in i:
				flag=True
				if j==i[0]:
				#print(f"Tor traffic Detected: {i} where {j} is a Tor node ip ")
					#print(f"[+] IP: {i[1]} is using TOR !!!! ")
					LocalIPs.append(i[1])
					# LocalIPs.append(i[0])
					TorIPs.append(i[0])
				else:
					#print(f"[+] IP: {i[0]} is using TOR !!!! ")
					LocalIPs.append(i[0])
					#LocalIPs.append(i[1])
					TorIPs.append(i[1])
			else:
				continue
	if flag==True:
		print(colored("Traffic Coming Behind Proxy Server!!!",'yellow'))
		print(colored("\nThese IPs are communicating with Proxy Server: ",'yellow'))
		for l in set(LocalIPs):
			print(colored(l,'blue'))
		print("--------------------------------------------------------------\n")
		print(colored("These are the Proxy Server IPs that communicated with our network:",'yellow'))
		for t in set(TorIPs):
			print(colored(t,'red'))
		print("--------------------------------------------------------------\n")
	else:
		print(colored("No Proxy Server traffic was found!!!!!!",'yellow'))
		print("--------------------------------------------------------------\n")

#srcDstList = list(ips)
	#print(srcDstList)
#	for i in srcDstList:
		#print(i)
##		for j in List:
#			if j in i:
				#print(f"Tor traffic Detected: {i} where {j} is a Tor node ip ")
