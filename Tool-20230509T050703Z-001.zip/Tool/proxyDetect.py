from modules import *


while True:
	#os.system("clear")
	banner = pyfiglet.figlet_format("PROXY IP TRACKER", font = "slant")
	print(colored(banner , 'red'))
	print(colored("                                                                 TEAM : P3AS  \n      ",'yellow'))

	print(colored("1.Capture packets with tcpdump\n",'green'))
	print(colored("2.Analyze pcap file \n",'green'))
	print(colored("3.To check if an IP is a Behind Proxy Sever and fetch geolocation \n",'green'))
	print(colored("4.Update Database\n",'green'))
	print(colored("5.Exit program\n",'green'))
	print(colored("\nChoose an option: ", 'blue'))
	opt=input("")

	if opt=="1":
		packet_capture()


	elif opt=="2":
		analyze()
	elif opt=="3":
		checkip()
	elif opt=="4":
		Update_Database()
	elif opt=="5":
		break
	else:
		print(colored("Wrong Option !!!!!!",'red'))
